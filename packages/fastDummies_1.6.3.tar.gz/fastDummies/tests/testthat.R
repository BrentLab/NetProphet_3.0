library(testthat)
library(fastDummies)

test_check("fastDummies")
